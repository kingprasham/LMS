// Course Detail Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Get course ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = parseInt(urlParams.get('id')) || 1;

    // Add to cart button
    const addToCartBtn = document.querySelector('.add-to-cart-btn');
    if (addToCartBtn) {
        addToCartBtn.addEventListener('click', function() {
            window.udemyApp.addToCart(courseId);
        });
    }

    // Wishlist button
    const wishlistBtn = document.querySelector('.wishlist-btn');
    if (wishlistBtn) {
        wishlistBtn.addEventListener('click', function() {
            window.udemyApp.addToWishlist(courseId);
        });
    }

    // Buy now button
    const buyNowBtn = document.querySelector('.btn-outline-secondary');
    if (buyNowBtn && buyNowBtn.textContent.includes('Buy now')) {
        buyNowBtn.addEventListener('click', function() {
            window.udemyApp.addToCart(courseId);
            window.location.href = 'payment.html';
        });
    }

    // Play preview video
    const playOverlay = document.querySelector('.play-overlay');
    if (playOverlay) {
        playOverlay.addEventListener('click', function() {
            alert('Video preview would play here. This is a demo.');
        });
    }
});
