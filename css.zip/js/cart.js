// Cart Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    loadCartItems();
    setupCartActions();
});

function loadCartItems() {
    const cartItems = window.udemyApp.cartItems;

    if (cartItems.length === 0) {
        showEmptyCart();
        return;
    }

    // Update cart count in heading
    const heading = document.querySelector('.cart-items-section h3');
    if (heading) {
        heading.textContent = `${cartItems.length} Course${cartItems.length > 1 ? 's' : ''} in Cart`;
    }

    // Calculate total
    const total = cartItems.reduce((sum, item) => sum + item.price, 0);
    const originalTotal = cartItems.reduce((sum, item) => sum + item.price + 1000, 0);

    // Update total in checkout box
    updateTotalDisplay(total, originalTotal);
}

function showEmptyCart() {
    const container = document.querySelector('.cart-items-section');
    if (container) {
        container.innerHTML = `
            <div class="empty-state" style="text-align: center; padding: 4rem 2rem;">
                <i class="bi bi-cart3" style="font-size: 4rem; color: var(--text-gray);"></i>
                <h3>Your cart is empty</h3>
                <p>Keep shopping to find a course!</p>
                <a href="../index.html" class="btn btn-primary mt-3">Keep Shopping</a>
            </div>
        `;
    }
}

function updateTotalDisplay(total, originalTotal) {
    const totalElement = document.querySelector('.total-section h2');
    const originalElement = document.querySelector('.original-total');

    if (totalElement) {
        totalElement.textContent = `₹${total}`;
    }

    if (originalElement) {
        originalElement.innerHTML = `<s>₹${originalTotal}</s>`;
    }
}

function setupCartActions() {
    // Remove buttons
    const removeButtons = document.querySelectorAll('.btn-remove');
    removeButtons.forEach((btn, index) => {
        btn.addEventListener('click', function() {
            const cartItems = window.udemyApp.cartItems;
            if (cartItems[index]) {
                window.udemyApp.removeFromCart(cartItems[index].id);
            }
        });
    });

    // Save for later buttons
    const saveButtons = document.querySelectorAll('.btn-save');
    saveButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            alert('Course saved for later! This feature is coming soon.');
        });
    });

    // Move to wishlist buttons
    const wishlistButtons = document.querySelectorAll('.btn-wishlist');
    wishlistButtons.forEach((btn, index) => {
        btn.addEventListener('click', function() {
            const cartItems = window.udemyApp.cartItems;
            if (cartItems[index]) {
                window.udemyApp.addToWishlist(cartItems[index].id);
                window.udemyApp.removeFromCart(cartItems[index].id);
            }
        });
    });

    // Apply coupon button
    const applyButton = document.querySelector('.input-group button');
    if (applyButton) {
        applyButton.addEventListener('click', function() {
            const input = document.querySelector('.input-group input');
            if (input && input.value) {
                alert(`Coupon "${input.value}" applied successfully!`);
            }
        });
    }

    // Close promo button
    const closePromo = document.querySelector('.close-promo');
    if (closePromo) {
        closePromo.addEventListener('click', function() {
            this.parentElement.remove();
        });
    }
}
