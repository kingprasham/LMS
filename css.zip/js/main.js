// Main JavaScript file for Udemy Clone

// Sample course data
const courses = [
    {
        id: 1,
        title: "Learning Python for Data Analysis and Visualization",
        author: "Jose Portilla",
        rating: 4.4,
        price: 455,
        image: "https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=480&h=270&fit=crop",
        category: "Development",
        level: "All Levels"
    },
    {
        id: 2,
        title: "The Complete Web Developer Course 2.0",
        author: "Rob Percival",
        rating: 4.5,
        price: 455,
        image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=480&h=270&fit=crop",
        category: "Development",
        level: "All Levels"
    },
    {
        id: 3,
        title: "Machine Learning A-Z™: Hands-On Python & R In Data Science",
        author: "Kirill Eremenko",
        rating: 4.5,
        price: 455,
        image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=480&h=270&fit=crop",
        category: "Data Science",
        level: "All Levels"
    },
    {
        id: 4,
        title: "Angular - The Complete Guide (2024 Edition)",
        author: "Maximilian Schwarzmüller",
        rating: 4.6,
        price: 455,
        image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=480&h=270&fit=crop",
        category: "Development",
        level: "All Levels"
    },
    {
        id: 5,
        title: "React - The Complete Guide (incl Hooks, React Router, Redux)",
        author: "Maximilian Schwarzmüller",
        rating: 4.6,
        price: 455,
        image: "https://images.unsplash.com/photo-1633356122102-3fe601e05bd2?w=480&h=270&fit=crop",
        category: "Development",
        level: "All Levels"
    },
    {
        id: 6,
        title: "The Complete JavaScript Course 2024",
        author: "Jonas Schmedtmann",
        rating: 4.7,
        price: 455,
        image: "https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?w=480&h=270&fit=crop",
        category: "Development",
        level: "Beginner"
    }
];

// Initialize cart count from localStorage
let cartItems = JSON.parse(localStorage.getItem('cart')) || [];
let wishlistItems = JSON.parse(localStorage.getItem('wishlist')) || [];

// Update cart count on page load
document.addEventListener('DOMContentLoaded', function() {
    updateCartCount();
    loadCourses();
    initializeEventListeners();
});

// Update cart count in header
// Update cart count in header
function updateCartCount() {
    const cartCountElements = document.querySelectorAll('#cart-count, #mobile-cart-count');
    cartCountElements.forEach(el => {
        if (el) {
            el.textContent = cartItems.length;
        }
    });
}

// Load courses on homepage
function loadCourses() {
    const coursesContainer = document.getElementById('courses-container');
    const trendingContainer = document.getElementById('trending-courses');

    if (coursesContainer) {
        coursesContainer.innerHTML = '';
        courses.slice(0, 5).forEach(course => {
            coursesContainer.appendChild(createCourseCard(course));
        });
    }

    if (trendingContainer) {
        trendingContainer.innerHTML = '';
        courses.forEach(course => {
            trendingContainer.appendChild(createCourseCard(course));
        });
    }
}

// Create course card element
function createCourseCard(course) {
    const card = document.createElement('div');
    card.className = 'course-card-wrapper';

    const courseDetails = getCourseDetails(course);

    card.innerHTML = `
        <a href="pages/course-detail.html?id=${course.id}" class="prodLink" style="text-decoration: none; color: inherit;">
            <div class="prodcard">
                <img class="prodimg" src="${course.image}" alt="${course.title}">
                <h3 class="card-title">${course.title}</h3>
                <div class="author">${course.author}</div>
                <div class="rating-div">
                    <span class="rate-num">${course.rating}</span>
                    ${createStars(course.rating)}
                    <span class="rate-count">(1,200)</span>
                </div>
                <div class="price-bar">
                    <span class="price">₹${course.price}</span>
                    <span class="oldprice">₹${course.price + 1000}</span>
                </div>

                <!-- Hover Overlay -->
                <div class="course-hover-overlay">
                    <div class="hover-content">
                        <h3 class="hover-title">${course.title}</h3>
                        <p class="hover-updated"><span class="badge bg-success">Bestseller</span> Updated November 2025</p>
                        <p class="hover-meta">${courseDetails.duration} • ${course.level} • Subtitles</p>
                        <p class="hover-description">${courseDetails.description}</p>

                        <ul class="hover-features">
                            ${courseDetails.features.map(feature => `<li><i class="bi bi-check2"></i> ${feature}</li>`).join('')}
                        </ul>

                        <div class="hover-actions">
                            <button class="btn btn-primary w-100 add-to-cart-btn" onclick="event.preventDefault(); event.stopPropagation(); addToCart(${course.id});">
                                Add to cart
                            </button>
                            <button class="btn-icon-round" onclick="event.preventDefault(); event.stopPropagation(); addToWishlist(${course.id});" title="Add to wishlist">
                                <i class="bi bi-heart"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    `;

    return card;
}

// Get detailed course information
function getCourseDetails(course) {
    const details = {
        'Python': {
            duration: '17 total hours',
            description: 'Master AI Agents in 30 days: build 8 real-world projects with OpenAI Agents SDK, CrewAI, LangGraph, AutoGen and MCP.',
            features: [
                'Project 1: Career Digital Twin. Build and deploy your own Agent to represent you to potential future employers.',
                'Project 2: SDR Agent. An instant business application: create Sales Representatives that craft and send professional emails.',
                'Project 3: Deep Research. Make your own version of the essential Agentic use case: a team of Agents that carry out extensive research on any topic you choose.'
            ]
        },
        'Web Development': {
            duration: '42 total hours',
            description: 'Learn Web Development by building 25 websites and mobile apps using HTML, CSS, JavaScript, PHP, Python, MySQL & more!',
            features: [
                'Build 25 real-world websites and mobile apps',
                'Learn to program in JavaScript, PHP, Python',
                'Master both front-end and back-end development',
                'Create a blog, e-Commerce sites, mobile apps'
            ]
        }
    };

    return details[course.category] || {
        duration: '20 total hours',
        description: `Master ${course.title} with comprehensive hands-on training and real-world projects.`,
        features: [
            'Build real-world projects from scratch',
            'Learn industry best practices',
            'Get hands-on coding experience',
            'Master the fundamentals and advanced concepts'
        ]
    };
}

// Create star rating HTML
function createStars(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    let starsHtml = '';

    for (let i = 0; i < fullStars; i++) {
        starsHtml += '<i class="bi bi-star-fill stars"></i>';
    }

    if (hasHalfStar) {
        starsHtml += '<i class="bi bi-star-half stars"></i>';
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
        starsHtml += '<i class="bi bi-star stars"></i>';
    }

    return starsHtml;
}

// Add to cart functionality
function addToCart(courseId) {
    const course = courses.find(c => c.id === courseId);
    if (course && !cartItems.find(item => item.id === courseId)) {
        cartItems.push(course);
        localStorage.setItem('cart', JSON.stringify(cartItems));
        updateCartCount();
        showNotification('Course added to cart!');
    } else {
        showNotification('Course is already in cart!');
    }
}

// Add to wishlist functionality
function addToWishlist(courseId) {
    const course = courses.find(c => c.id === courseId);
    if (course && !wishlistItems.find(item => item.id === courseId)) {
        wishlistItems.push(course);
        localStorage.setItem('wishlist', JSON.stringify(wishlistItems));
        showNotification('Course added to wishlist!');
    } else {
        showNotification('Course is already in wishlist!');
    }
}

// Remove from cart
function removeFromCart(courseId) {
    cartItems = cartItems.filter(item => item.id !== courseId);
    localStorage.setItem('cart', JSON.stringify(cartItems));
    updateCartCount();
    showNotification('Course removed from cart!');

    // Reload page if on cart page
    if (window.location.pathname.includes('cart.html')) {
        window.location.reload();
    }
}

// Show notification
function showNotification(message) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        background-color: #1c1d1f;
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 4px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 9999;
        animation: slideIn 0.3s ease-out;
    `;

    document.body.appendChild(notification);

    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Initialize event listeners
function initializeEventListeners() {
    // Mobile Hamburger Menu
    const hamburgerBtn = document.getElementById('hamburger-btn');
    const closeMenuBtn = document.getElementById('close-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');
    const mobileMenuOverlay = document.getElementById('mobile-menu-overlay');

    if (hamburgerBtn && mobileMenu && mobileMenuOverlay) {
        hamburgerBtn.addEventListener('click', function() {
            mobileMenu.classList.add('active');
            mobileMenuOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        });

        closeMenuBtn.addEventListener('click', function() {
            mobileMenu.classList.remove('active');
            mobileMenuOverlay.classList.remove('active');
            document.body.style.overflow = '';
        });

        mobileMenuOverlay.addEventListener('click', function() {
            mobileMenu.classList.remove('active');
            mobileMenuOverlay.classList.remove('active');
            document.body.style.overflow = '';
        });
    }

    // Topic tabs
    const topicTabs = document.querySelectorAll('.topic-tab');
    topicTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            topicTabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Skills tabs
    const skillsTabs = document.querySelectorAll('.skills-tab');
    skillsTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            skillsTabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            const skill = this.getAttribute('data-skill');
            showNotification(`Showing ${this.textContent} courses`);
        });
    });

    // Search functionality
    const searchInputs = document.querySelectorAll('.searchbar input');
    searchInputs.forEach(input => {
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const searchTerm = this.value;
                console.log('Searching for:', searchTerm);
                showNotification(`Searching for: ${searchTerm}`);
            }
        });
    });

    // Skills carousel navigation
    const skillsTrack = document.querySelector('.skills-cards-track');
    const skillsPrevBtn = document.getElementById('skillsPrevBtn');
    const skillsNextBtn = document.getElementById('skillsNextBtn');
    const skillsDots = document.querySelectorAll('#skillsDots .dot');

    if (skillsTrack && skillsPrevBtn && skillsNextBtn) {
        let currentSlide = 0;
        const cardWidth = 350 + 24; // card width + gap
        const totalCards = document.querySelectorAll('.skill-category-card').length;
        const maxSlide = totalCards - 1;

        skillsNextBtn.addEventListener('click', () => {
            if (currentSlide < maxSlide) {
                currentSlide++;
                skillsTrack.scrollLeft = currentSlide * cardWidth;
                updateDots();
            }
        });

        skillsPrevBtn.addEventListener('click', () => {
            if (currentSlide > 0) {
                currentSlide--;
                skillsTrack.scrollLeft = currentSlide * cardWidth;
                updateDots();
            }
        });

        skillsDots.forEach((dot, index) => {
            dot.addEventListener('click', () => {
                currentSlide = index;
                skillsTrack.scrollLeft = currentSlide * cardWidth;
                updateDots();
            });
        });

        function updateDots() {
            skillsDots.forEach((dot, index) => {
                dot.classList.toggle('active', index === currentSlide);
            });
        }
    }
}

// Export functions for use in other files
window.udemyApp = {
    addToCart,
    addToWishlist,
    removeFromCart,
    courses,
    cartItems,
    wishlistItems
};

// ============================================
// NEW SECTIONS INTERACTIVE FUNCTIONALITY
// ============================================

// FAQ Accordion
function initFAQ() {
    const faqItems = document.querySelectorAll('.faq-item');

    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');

        question.addEventListener('click', () => {
            // Close other FAQs
            faqItems.forEach(otherItem => {
                if (otherItem !== item && otherItem.classList.contains('active')) {
                    otherItem.classList.remove('active');
                }
            });

            // Toggle current FAQ
            item.classList.toggle('active');
        });
    });
}

// Testimonials Slider - Continuous Horizontal Scrolling
function initTestimonials() {
    const track = document.getElementById('testimonial-track');
    const slider = document.querySelector('.testimonials-slider');

    if (!track || !slider) return;

    const cards = Array.from(document.querySelectorAll('.testimonial-card'));
    if (cards.length === 0) return;

    // Clone all cards multiple times to create seamless infinite loop
    const cloneCount = 3;
    for (let i = 0; i < cloneCount; i++) {
        cards.forEach(card => {
            const clone = card.cloneNode(true);
            track.appendChild(clone);
        });
    }

    let scrollPosition = 0;
    const scrollSpeed = 0.8; // pixels per frame
    let animationFrame;
    let isPaused = false;

    function startScrolling() {
        if (isPaused) {
            animationFrame = requestAnimationFrame(startScrolling);
            return;
        }

        scrollPosition += scrollSpeed;

        // Calculate total width of original cards
        const cardWidth = cards[0].offsetWidth;
        const gap = 30;
        const totalWidth = (cardWidth + gap) * cards.length;

        // Reset position seamlessly when we've scrolled through all original cards
        if (scrollPosition >= totalWidth) {
            scrollPosition = 0;
        }

        track.style.transform = `translateX(-${scrollPosition}px)`;
        animationFrame = requestAnimationFrame(startScrolling);
    }

    function pauseScrolling() {
        isPaused = true;
    }

    function resumeScrolling() {
        isPaused = false;
    }

    // Pause on hover - use slider container to capture all hover events
    slider.addEventListener('mouseenter', pauseScrolling);
    slider.addEventListener('mouseleave', resumeScrolling);

    // Pause on touch (for mobile)
    slider.addEventListener('touchstart', pauseScrolling);
    slider.addEventListener('touchend', resumeScrolling);

    // Start the animation
    startScrolling();

    // Handle window resize
    let resizeTimer;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
            scrollPosition = 0;
        }, 250);
    });
}

// Scroll Animations - Intersection Observer
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animationPlayState = 'running';
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observe all fade-in elements
    document.querySelectorAll('.fade-in-up').forEach(el => {
        el.style.animationPlayState = 'paused';
        observer.observe(el);
    });
}

// Smooth Scrolling for Anchor Links
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (href === '#') return;

            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Blog Load More Functionality
function initBlogLoadMore() {
    const loadMoreBtn = document.querySelector('.load-more-btn');
    if (!loadMoreBtn) return;

    loadMoreBtn.addEventListener('click', () => {
        // Simulate loading more blog posts
        loadMoreBtn.innerHTML = '<i class="bi bi-arrow-repeat"></i> Loading...';
        loadMoreBtn.style.pointerEvents = 'none';

        setTimeout(() => {
            loadMoreBtn.innerHTML = 'Load More Articles <i class="bi bi-arrow-down"></i>';
            loadMoreBtn.style.pointerEvents = 'auto';
            alert('No more articles to load!');
        }, 1000);
    });
}

// Contact Form Submission
function initContactForm() {
    const contactForm = document.getElementById('contact-form');
    if (!contactForm) return;

    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();

        const formData = new FormData(contactForm);
        const data = Object.fromEntries(formData);

        // Simulate form submission
        const submitBtn = contactForm.querySelector('.submit-btn');
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Sending...';
        submitBtn.disabled = true;

        setTimeout(() => {
            alert('Thank you for contacting us! We will get back to you soon.');
            contactForm.reset();
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }, 1500);
    });
}

// Initialize all new features when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initFAQ();
    initTestimonials();
    initScrollAnimations();
    initSmoothScroll();
    initBlogLoadMore();
    initContactForm();
});


